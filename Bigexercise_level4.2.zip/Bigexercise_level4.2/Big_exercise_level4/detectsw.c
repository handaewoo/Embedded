
#include "detectsw.h"    /* Standard IO library: sprintf */


unsigned int j, k;
unsigned int check;

unsigned int enable_switch;
/******************************************************************************
* Function Name: getswitch
* Description  : check Switch and reduce chattering
* Arguments    : none
* Return Value : none
******************************************************************************/
unsigned int getswitch(){
	
	check = PRESS;
	switch(check){
		
		case SW3:
			if(enable_switch == 1){
				delay();
				enable_switch = 0;
				check = SW3;
			}else {
				check = 0;
			}
			break;
			
		default:
			delay();
			enable_switch = 1;
			check = 0;
			break;
	}
	
	return check;
}
/******************************************************************************
* Function Name: delay
* Description  : delay for reduce noise 
* Arguments    : none
* Return Value : none
******************************************************************************/
void delay(){
	for (j = 0; j < 300; j++){
		for (k = 0; k < 2000; k++){
			if(PRESS != 0x07){
				break;
			}
		}
	}
}