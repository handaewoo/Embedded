/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : record.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 01.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"
#include "record.h"
#include <string.h>
#include "stdio.h"
#include "lcd.h"
#include "timer.h"
#include "check_button.h"
/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
char pause[LCD_LEN] = "Pausing...";
char run[LCD_LEN] = "Running...";
char no_record[LCD_LEN] = "No record";
char first[LCD_LEN] = "First record";
char last[LCD_LEN] = "Last record";

unsigned int num_record;
unsigned int num;
unsigned int record_status;
int scroll;

record data[BUFF_LEN];
char buff[LCD_LEN];
/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/
unsigned int MODE;

/******************************************************************************
* Function Name: check_record
* Description  : This function use to check record status
* Arguments    : none
* Return Value : none
******************************************************************************/

void check_record()
{ 
	if(num_record == FIRST_SS)
	{
		DisplayLCD(LCD_LINE1,(uint8_t *) no_record);
		record_status = NO_RECORD;
		t2s = ZERO;
	}
	else if((num_record <= LCD_ROW_LEN)&&(check == SW1))
	{
		DisplayLCD(LCD_LINE1,(uint8_t *) first);
		record_status = MODE2;
		t2s = ZERO;
	}
	else if((num_record <= LCD_ROW_LEN)&&(check == SW2))
	{
		DisplayLCD(LCD_LINE1,(uint8_t *) last);
		record_status = MODE3;
		t2s = ZERO;
	}
	else record_status = MODE1;
}


/******************************************************************************
* Function Name: scroll_up
* Description  : This function use to scroll up to see privious value
* Arguments    : none
* Return Value : none
******************************************************************************/

void scroll_up()
{ 
	int i,y;
	i=ZERO;
	y=1;
	scroll++;
	if(scroll >= num_record-LCD_ROW_LEN)
	{
		scroll = num_record-LCD_ROW_LEN;
		DisplayLCD(LCD_LINE1 ,(uint8_t *)first);	
		record_status =MODE2 ;	//First Record	
		t2s = ZERO;
	}
	else
	{
	Return_LCD();	
	}
	for(i=(num_record-(LCD_ROW_LEN-1))-scroll;i<=num_record-scroll;i++)
	{
		unsigned char x = (unsigned char )(LCD_LINE2+NEXT_LINE*y);
		DisplayLCD(x ,(uint8_t *) data[i].ar);
		y++;
	}
}

/******************************************************************************
* Function Name: scroll_up
* Description  : This function use to scroll down to see lastest value
* Arguments    : none
* Return Value : none
******************************************************************************/
void scroll_down()
{ 
	int i,y;
	i=ZERO;
	y=1;
	scroll--;
	if(scroll <= ZERO)
	{
		scroll = ZERO;
		DisplayLCD(LCD_LINE1 ,(uint8_t *)last);	
		record_status =MODE3 ;		
		t2s  = ZERO;
	}
	else
	{
		Return_LCD();	
	}
	for(i=(num_record-(LCD_ROW_LEN-1))-scroll;i<=num_record-scroll;i++)
	{
		unsigned char x = (unsigned char) (LCD_LINE2+NEXT_LINE*y);
		DisplayLCD(x ,(uint8_t *) data[i].ar);
		y++;
	}
}

/******************************************************************************
* Function Name: save_record
* Description  : This function use to save value when we 're pressing switch 3 and stopwatch is running 
* Arguments    : none
* Return Value : none
******************************************************************************/
void save_record()
{
	int i;
	int y;
	num_record++;
	num++;
	scroll =ZERO;	
	
	if (num_record > LAST_SS)
	{
		num_record = LAST_SS;
	}
	sprintf( data[num_record].ar , "#%d:%0.2d:%0.2d:%0.2d",num, g_time.minute , g_time.second,g_time.centi_second);
	if (num_record < SEC_SS)
	{
		for(i =1 ; i <= num_record; i++)
		{	
			unsigned char x = (unsigned char)(LCD_LINE2 + i*NEXT_LINE);
			DisplayLCD(x,(uint8_t *)data[i].ar);
		}
	}
	if (num_record >= SEC_SS && num_record <=THIRD_SS)/*if number of record >=6 till number of record <= max number*/
	{
		y=1;
		for(i = num_record - LCD_ROW_LEN ; i < num_record; i++)
		{	
			unsigned char x = (unsigned char)(LCD_LINE2 + y*NEXT_LINE);
			DisplayLCD(x,(uint8_t *)data[i+1].ar);
			y++;
			
		}
	}
	if (num_record >THIRD_SS)	/*if number of record > max number*/
	{ 
		y=1;
		shift_value();
		for(i = num_record - LCD_ROW_LEN ; i < num_record; i++)
		{	
			unsigned char x = (unsigned char)(LCD_LINE2 + y*NEXT_LINE);
			DisplayLCD(x,(uint8_t *)data[i].ar);
			y++;
				
		}
		num_record =THIRD_SS;
	}
	
}
/******************************************************************************
* Function Name: shift_value
* Description  : This function use to display status of LCD
* Arguments    : none
* Return Value : none
******************************************************************************/
void shift_value()
{
	int i;
	for(i=1;i<LAST_SS;i++)
	{ 
		strcpy(data[i].ar,data[i+1].ar);
	}
}

/******************************************************************************
* Function Name: Return_LCD
* Description  : This function use to display om LCD after 
* Arguments    : none
* Return Value : none
******************************************************************************/

void Return_LCD()
{ 
	if(MODE == RUNNING)
		DisplayLCD(LCD_LINE1,(uint8_t *)run);
	else if(MODE == PAUSING)
		DisplayLCD(LCD_LINE1,(uint8_t *)pause);
}
/******************************************************************************
* Function Name: reset_value
* Description  : This function use to reset stopwatch
* Arguments    : none
* Return Value : none
******************************************************************************/
void reset_value()
{
	int i;
	ClearLCD();
	g_time.centi_second = ZERO;
	g_time.second = ZERO;
	g_time.minute = ZERO;
	num_record = ZERO;
	num = ZERO;
	sprintf(buff, "%0.2d:%0.2d:%0.2d",g_time.minute,g_time.second,g_time.centi_second);
	DisplayLCD(LCD_LINE2+1,(uint8_t *) buff);
	for(i=1;i<=THIRD_SS;i++)
	{
		strcpy(data[i].ar,"               ");
	}
}
/******************************************************************************
End of file
******************************************************************************/