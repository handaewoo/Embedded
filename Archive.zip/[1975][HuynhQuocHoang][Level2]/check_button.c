#pragma sfr
/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : check_button.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 01.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"
#include "check_button.h"
#include "record.h"
#include <string.h>
#include "lcd.h"
/******************************************************************************
Typedef definitions
******************************************************************************/
extern Delay_10ms();
int match_time;
int enable_switch;
unsigned int check; 

/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
int prevoutput = P7_ADR;
int output = P7_ADR;
int prev = P7_ADR;
int current;
int match_times = WR;
/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/

/******************************************************************************
* Function Name: getSW
* Description  : This function use to check switch status, check record to scroll or scroll down time of stop watch
* Arguments    : none
* Return Value : SW1 or SW2 or SW3 or SW1_2 depend on we press.
******************************************************************************/
void get_SW()
{
	check = ClearChattering();
	if(check==SW1)
	{
		check_record();
		if(record_status==MODE1)
			scroll_up();
	}
	else if(check == SW2)
	{
		check_record();
		if(record_status==MODE1)
			scroll_down();
	}
	else if(check==SW3)
	{
		if(MODE==RUNNING)
			save_record(); 
		else if(MODE==PAUSING)
		{
			MODE = RUNNING;
			DisplayLCD(LCD_LINE1 ,(uint8_t *)run);
		}
	}
	else if(check==SW1_2)
	{
		if(MODE==RUNNING)
		{
			MODE = PAUSING;
			DisplayLCD(LCD_LINE1 ,(uint8_t *)pause);
		}
		else if(MODE==PAUSING)
		{
			reset_value();
			DisplayLCD(LCD_LINE1 ,(uint8_t *)pause);
		}
	}
}
/******************************************************************************
* Function Name: ClearChattering
* Description  : This function use to check button whether press or not and chattering switch.
* Arguments    : none
* Return Value : SW1 or SW2 or SW3 or SW1_2 depend on we press.
******************************************************************************/

int ClearChattering(void)
{
	prevoutput = output;
	current = (P7&P7_ADR);
	if(prev!=current){
		match_times=WR;
		prev=current;
	}
	else{
		match_times=match_times+1;
		if(match_times>CR)
		{
			match_times=WR;
			output=current;
			if (output == 0x20 && prevoutput != 0x20)
			{
				prevoutput = P7_ADR;
			}
		}
		

	}
  	return (output ^ prevoutput) & (~output);
}
/******************************************************************************
End of file
******************************************************************************/