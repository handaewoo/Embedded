#pragma sfr
/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : timer.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 01.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"
#include "delay.h"
#include <string.h>
#include "lcd.h"
/******************************************************************************
Typedef definitions
******************************************************************************/
#define ASM_delay // this use for ASM delay MOD
time_t  g_time;
extern Delay_10ms();
uint8_t MODE;
int count;
char string[5];
/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/
 /******************************************************************************
* Function Name: wait
* Description  : Delay 1 s use C function
* Arguments    : none
* Return Value : none
******************************************************************************/
void wait(void)
{
	int i ;
	for (i =0 ; i <CYCLE; i++)
	{
		int j= CYCLE_2 ;
		while (j >0)
		{
			j--;
		}
		if(SW3==ON) 
		{
			break;
		}
	}
	i = 0 ;
}


 /******************************************************************************
* Function Name: delay_1s
* Description  : delay 1s value of g_time in Counting status, this function use ASM code
* Arguments    : none
* Return Value : none
******************************************************************************/
void delay_1s(void)
{
#ifdef ASM_delay
	
	while( count > ZERO)
	{
		count = count -1;
		/*call delay function assembly*/
		if(SW3==ON) 
		{
			break;
		}
		Delay_10ms();
	}
	if(ZERO==count) count=COUNT_TIME_1S;
#else
	/*call delay function*/
	wait();
#endif
	/*handle delay interupt*/
		/*condition to decrease minute value*/	
		if(SW3!=ON) 
		{
			if( (g_time.second) == ZERO&& g_time.minute !=ZERO ) 
			{ 	/*decrease minute value */
				g_time.minute--;    
				/*reset max second value */
				g_time.second =59;
			}
			else if (g_time.minute ==ZERO && g_time.second ==ZERO)
			{
				g_time.minute=ZERO;
				g_time.second =ZERO;
				MODE=2;
				DisplayLCD(LCD_LINE1, (uint8_t *)"Setting... ");
			}
			/*decrease second value*/
			else{
				g_time.second--;
			}
			sprintf(string, "%0.2d:%0.2d",g_time.minute,g_time.second);
			DisplayLCD(LCD_LINE2, string);
			/*reset delay interupt flag*/	
		}
		
}


/******************************************************************************
Private global variables and functions
******************************************************************************/

/******************************************************************************
End of file
******************************************************************************/