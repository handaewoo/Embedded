#pragma sfr
/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 03.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/

#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "delay.h"    /* delay library*/
#include "stdio.h"    /* Standard IO library: sprintf */
#include <string.h>
/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/
// ANOTHER define IN FILE delay.h
#define MODE1 0 //PAUSE
#define MODE2 1	//COUNTING
#define MODE3 2 //SETTING

#define CON_SW 0x70    //This is configure register SW1, SW2, SW3 in port 7 

#define TIME 60 // This macro use when Time count enough
#define MAT 3 // This macro use for match time when it chattering

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/
extern Delay_10ms();

char string2[5]; // this variable use for storage string convert from second and minute
int match_time;//This bit check whether time is correct or not

/******************************************************************************
Private global variables and functions
******************************************************************************/
void r_main_userinit(void);
void initial_init();
int chattering();
void check_button();
/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	
	/* Initialize user system */
	r_main_userinit();
	initial_init();
	
	/* Clear LCD display */
	ClearLCD();
	
	/*initial variable*/
	MODE=MODE3; // SETTING TIME TO COUNT.
	g_time.second=ZERO;
	g_time.minute=ZERO;
	match_time=ZERO;
	count=COUNT_TIME_1S;
	
	/* Print message to the first line and second of LCD */
	DisplayLCD(LCD_LINE1, (uint8_t *)"Setting...");
	sprintf(string2, "%0.2d:%0.2d",g_time.minute,g_time.second);// convert time to string.
	DisplayLCD(LCD_LINE2, string2);
	
	/* Main loop - Infinite loop */
	while (1) 
	{
		if(MODE==MODE2) 
		{
			delay_1s();
		}
		else;	
		check_button();
	}
}

/******************************************************************************
* Function Name: r_main_userinit
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/
void r_main_userinit(void)
{
	uint16_t i;

	/* Enable interrupt */
	EI();

	/* Output a logic LOW level to external reset pin*/
	P13_bit.no0 = 0;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Generate a raising edge by ouput HIGH logic level to external reset pin */
	P13_bit.no0 = 1;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Output a logic LOW level to external reset pin, the reset is completed */
	P13_bit.no0 = 0;
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	/* Initialize LCD driver */
	InitialiseLCD();	
}
/******************************************************************************
* Function Name: check_button
* Description  : This function use to check button whether press or not and change MODE when we press
* Arguments    : none
* Return Value : none
******************************************************************************/
void check_button()
{
	if(SW3==ON)
	{
		if(chattering())
		{
			if(MODE==MODE2) 
			{
				MODE=MODE1;
				DisplayLCD(LCD_LINE1, (uint8_t *)"Pausing... ");
			}
			else if(MODE==MODE1||MODE==MODE3)
			{
				MODE=MODE2;
				DisplayLCD(LCD_LINE1, (uint8_t *)"Counting...");
			}
			if(g_time.minute ==ZERO && g_time.second ==ZERO)
			{
				MODE=MODE3;
				DisplayLCD(LCD_LINE1, (uint8_t *)"Setting... ");
			}
			while(SW3==ON){}
		}
	}
	if(SW2==ON)
	{
		if(chattering())
		{
			if(MODE==MODE1)
			{
				MODE=MODE3;
				g_time.second=ZERO;
				g_time.minute=ZERO;
				sprintf(string2, "%0.2d:%0.2d",g_time.minute,g_time.second);
				DisplayLCD(LCD_LINE1, (uint8_t *)"Setting... ");
				DisplayLCD(LCD_LINE2, string2);
				while(SW2==ON){}
			}
			else if(MODE==MODE3)
			{
				g_time.minute++;
				if(g_time.minute==TIME)
					g_time.minute=ZERO;
				sprintf(string2, "%0.2d:%0.2d",g_time.minute,g_time.second);
				DisplayLCD(LCD_LINE1, (uint8_t *)"Setting... ");
				DisplayLCD(LCD_LINE2, string2);
				while(SW2==ON){}
			}
		}
	}
	if(SW1==ON)
	{
		if(chattering())
		{
			if(MODE==MODE3)
			{	
				g_time.second++;
				if(g_time.second==TIME)
				{
					g_time.second=ZERO;
					g_time.minute++;
					if(g_time.minute==TIME)
						g_time.minute=ZERO;
				}
				DisplayLCD(LCD_LINE1, (uint8_t *)"Setting... ");
				sprintf(string2, "%0.2d:%0.2d",g_time.minute,g_time.second);
				DisplayLCD(LCD_LINE2, string2);
				while(SW1==ON){}
			}
			else;
		}
	}
}

/******************************************************************************
* Function Name: initial_init
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/
void initial_init()
{
	PM7 &=CON_SW;
}
/******************************************************************************
* Function Name: chattering
* Description  : User use this to chattering when press button
* Arguments    : none
* Return Value : 1 when it was chattering and return 0 when not chattering
******************************************************************************/
int chattering()
{
	//pre_final=final;
	if((SW3==ON)||(SW2==ON)||(SW1==ON))
	{
		Delay_10ms();
		match_time++;
		if(match_time>=MAT)
		{
			match_time=ZERO;
			return 1;
		}
	}
	else 
	{	
		match_time=ZERO;
	}
	return 0;
}


/******************************************************************************
End of file
******************************************************************************/

