#include "r_macro.h"  /* System macro and standard type definition */

#define RUNNING 1
#define PAUSING 2

#define MODE2 1 // first record
#define MODE3 2 // last record
#define MODE1 3 // cho phep scroll up and down
#define NO_RECORD 0

#define LCD_LEN		15
#define LCD_ROW_LEN 	6
#define ZERO		0




typedef struct
{
	char ar[15];
}record;
extern int f_flag;

extern record data[22];
extern unsigned int MODE;

extern unsigned int max_record;
extern unsigned int num;
extern unsigned int record_status;
extern int scroll;

extern char pause[15];
extern char run[15];
extern char no_record[15];
extern char first[15];
extern char last[15];

void Return_LCD();
void check_record();
void scroll_up();
void scroll_down();
void save_record();
void shift_value();
void reset_value();