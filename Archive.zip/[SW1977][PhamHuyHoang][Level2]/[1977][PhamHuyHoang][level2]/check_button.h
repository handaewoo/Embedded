
#include "r_macro.h"  /* System macro and standard type definition */


#define SW1	(0x40)
#define SW2	(0x10)
#define SW3	(0x20)
#define SW1_2	(0x50)
#define PRESS (P7&0x70)

#define P7_ADR 0x70


extern unsigned int check;
extern int enable_switch;
extern	int prevoutput;
extern	int output;
extern	int prev;
extern	int current;
extern	int match_times;
/******************************************************************************
* Function Name: get_SW
* Description  : check Switch and reduce chattering
* Arguments    : none
* Return Value : none
******************************************************************************/

void get_SW();


/******************************************************************************
* Function Name: chattering
* Description  : delay for reduce noise 
* Arguments    : none
* Return Value : none
******************************************************************************/
int ClearChattering(void);